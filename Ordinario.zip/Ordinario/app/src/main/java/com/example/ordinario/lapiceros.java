package com.example.ordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class lapiceros extends AppCompatActivity {
    Button btns9,nota;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lapiceros);
        btns9 = (Button) findViewById(R.id.btns9);
        nota = (Button) findViewById(R.id.nota);

        btns9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Regresaste a menu", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), menu.class);
                startActivity(i);
            }
        });
        nota.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "NOTA", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), Nota.class);
                startActivity(i);
            }
        });
    }
}