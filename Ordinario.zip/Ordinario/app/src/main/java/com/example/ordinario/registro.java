package com.example.ordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.Locale;

public class registro extends AppCompatActivity {
    EditText editn,editd;

    Button btn3,btn4;
    RadioButton mujer, hombre;

    SharedPreferences preferences;
    String nombre="",direccion="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        editn = (EditText) findViewById(R.id.editnombre);
        editd = (EditText) findViewById(R.id.editdirec);
        btn3 = (Button) findViewById(R.id.guardardatos);
        btn4 = (Button) findViewById(R.id.salir);
        mujer = (RadioButton) findViewById(R.id.mujer);
        hombre = (RadioButton) findViewById(R.id.hombre);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarCampos();
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "saliste de la aplicacion", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }


    private void validarCampos() {
        String Nombre="", Direccion="";
        nombre=editn.getText().toString();
        direccion=editd.getText().toString();

        String error="";error+="";
        if (nombre.equals("") || direccion.equals("") )
            error="--No puedes dejar campos vacios";
        if(!error.equals(""))
            Toast.makeText(getApplicationContext(), "ERROR"+error, Toast.LENGTH_LONG).show();
        if (!mujer.isChecked() && !hombre.isChecked())
            error+="--Selecciona tu genero";
        else {
            guardarDatos(nombre,direccion,mujer.isChecked());
            Intent i= new Intent(getApplicationContext(),menu.class);
            startActivity(i);
            Toast.makeText(getApplicationContext(), "Se registro correctamente tus datos"+nombre, Toast.LENGTH_LONG).show();
        }
    }
    private void guardarDatos(String name, String dir, boolean hombre){
        preferences=getSharedPreferences( "Registro", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor= preferences.edit();
        editor.putString("nombre",name);
        editor.putString("direccion",dir);
        if(hombre)
            editor.putString("genero","masculino");
        else
            editor.putString("genero","femenino");
        editor.commit();
    }


}



