package com.example.ordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class menu extends AppCompatActivity {
    Button btn5, btn6, btn7, imageButton2;
    ImageButton btn8;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        btn5 = (Button) findViewById(R.id.button);
        btn6 = (Button) findViewById(R.id.button2);
        btn7 = (Button) findViewById(R.id.button3);
        btn8 = (ImageButton) findViewById(R.id.imageButton2);



        btn5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Hiciste click en cuadernos", Toast.LENGTH_SHORT).show();
                Intent i= new Intent(getApplicationContext(),cuadernos.class);
                startActivity(i);
            }

        });
        btn6.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Hiciste click en lapiceros", Toast.LENGTH_SHORT).show();
                Intent i= new Intent(getApplicationContext(),lapiceros.class);
                startActivity(i);
            }

        });
        btn7.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Hiciste click en pegamentos", Toast.LENGTH_SHORT).show();
                Intent i= new Intent(getApplicationContext(),pegamentos.class);
                startActivity(i);
            }

        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAffinity();
                System.exit(0);
            }

        });

    }
}