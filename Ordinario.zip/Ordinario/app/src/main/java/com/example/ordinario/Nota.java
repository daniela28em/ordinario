package com.example.ordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Nota extends AppCompatActivity {
    Button btns9, btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nota);
        btn2 = (Button) findViewById(R.id.salir);
        btns9 = (Button) findViewById(R.id.btns9);

        btns9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Regresaste a menu", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), menu.class);
                startActivity(i);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Saliste de la aplicación", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }
}